package tipsit.garacavalliconthread;


import java.io.IOException;
import tipsit.garacavalliconthread.Gara;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author miste
 */
public class ProgCavalli {
    /**
     * Metodo main
     * @param a
     * @throws IOException 
     */
        public static void main(String[] a) throws IOException {
		Gara g = new Gara();
	}
}
